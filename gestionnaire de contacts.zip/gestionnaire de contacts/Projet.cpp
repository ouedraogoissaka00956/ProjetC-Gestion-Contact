#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

// Structure pour stocker les informations d'un contact
struct Contact {
    string nom;
    string numero;
    string email;
    string adresse;
    string sexe;
};

// Fonction pour valider le format de l'email
bool valideFormatEmail(const string &email) {
    size_t at = email.find('@');
    size_t dot = email.find('.', at);
    return (at != string::npos && dot != string::npos && at < dot);
}

// Fonction pour valider le format du sexe
bool validerFormatSexe(const string &sexe) {
    return (sexe == "F" || sexe == "M");
}

// Fonction pour ajouter un contact à la liste
void ajouterContact(vector<Contact> &contacts) {
    Contact nouveauContact;

    cout << "Entrez le nom du contact : ";
    cin >> nouveauContact.nom;

    cout << "Entrez le numero du contact : ";
    cin >> nouveauContact.numero;

    // Validation de l'email
    do {
        cout << "Entrer l'email du contact (format 'champ@gmail.com') : ";
        cin >> nouveauContact.email;
        if (!valideFormatEmail(nouveauContact.email)) {
            cout << "Le format de l'email entré est incorrect. Veuillez entrer un email valide.\n";
        }
    } while (!valideFormatEmail(nouveauContact.email));

    cout << "Entrez l'adresse du contact : ";
    cin.ignore(); // Pour ignorer le newline restant dans le buffer
    getline(cin, nouveauContact.adresse);

    // Validation du sexe
    do {
        cout << "Veuillez entrer le sexe du contact (F ou M) : ";
        cin >> nouveauContact.sexe;
        if (!validerFormatSexe(nouveauContact.sexe)) {
            cout << "Le format du sexe entré est incorrect. Veuillez entrer F pour féminin ou M pour masculin.\n";
        }
    } while (!validerFormatSexe(nouveauContact.sexe));

    contacts.push_back(nouveauContact);
    cout << "Contact ajouter dans le repertoire.\n";
}

// Fonction pour afficher la liste de tous les contacts enregistrés
void afficherListeContacts(const vector<Contact> &contacts) {
    if (!contacts.empty()) {
        cout << "Liste de contacts :\n";
        for (const auto &contact : contacts) {
            cout << "Nom : " << contact.nom << "\tNumero : " << contact.numero
                 << "\tEmail : " << contact.email << "\tAdresse : " << contact.adresse
                 << "\tSexe : " << contact.sexe << endl;
        }
    } else {
        cout << "La liste de contacts est vide.\n";
    }
}

// Fonction pour rechercher un contact par son nom
void rechercherContactParNom(const vector<Contact> &contacts) {
    if (!contacts.empty()) {
        string nomRecherche;
        cout << "Entrez le nom du contact a rechercher : ";
        cin >> nomRecherche;

        auto it = find_if(contacts.begin(), contacts.end(), [&](const Contact &c) {
            return c.nom == nomRecherche;
        });

        if (it != contacts.end()) {
            cout << "Contact trouver :\nNom : " << it->nom << "\tNumero : " << it->numero
                 << "\tEmail : " << it->email << "\tAdresse : " << it->adresse
                 << "\tSexe : " << it->sexe << endl;
        } else {
            cout << "Contact non trouver. Veuillez verifier le nom de votre contact rechercher.\n";
        }
    } else {
        cout << "La liste de contacts est vide.\n";
    }
}

// Fonction pour supprimer un contact à travers son nom
void supprimerContactParNom(vector<Contact> &contacts) {
    if (!contacts.empty()) {
        string nomSupprime;
        cout << "Entrez le nom du contact à supprimer : ";
        cin >> nomSupprime;

        auto it = remove_if(contacts.begin(), contacts.end(), [&](const Contact &c) {
            return c.nom == nomSupprime;
        });

        if (it != contacts.end()) {
            contacts.erase(it, contacts.end());
            cout << "Le contact a ete supprimer.\n";
        } else {
            cout << "Contact non trouver. Veuillez verifier si le nom du contact entrer est correct.\n";
        }
    } else {
        cout << "La liste de contacts est vide.\n";
    }
}

// Fonction pour mettre à jour un contact
void modifierContact(vector<Contact> &contacts) {
    if (!contacts.empty()) {
        string nomAjour;
        cout << "Entrez le nom du contact a modifier : ";
        cin >> nomAjour;

        auto it = find_if(contacts.begin(), contacts.end(), [&](const Contact &c) {
            return c.nom == nomAjour;
        });

        if (it != contacts.end()) {
            cout << "Veuillez entrer le nouveau nom du contact : ";
            cin >> it->nom;

            cout << "Veuillez entrer le nouvel email du contact : ";
            cin >> it->email;

            cout << "Veuillez entrer le nouveau numéro du contact : ";
            cin >> it->numero;

            cout << "Veuillez entrer la nouvelle adresse du contact : ";
            cin.ignore();
            getline(cin, it->adresse);

            cout << "Veuillez entrer le sexe du nouveau contact : ";
            cin >> it->sexe;

            cout << "Le contact a ete mis à jour avec succes.\n";
        } else {
            cout << "Contact non trouver. Veuillez vérifier le nom entrer.\n";
        }
    } else {
        cout << "La liste de contacts est vide.\n";
    }
}

// Fonction pour trier les contacts par nom
void trierContactsParNom(vector<Contact> &contacts) {
    sort(contacts.begin(), contacts.end(), [](const Contact &a, const Contact &b) {
        return a.nom < b.nom;
    });
    cout << "Contacts tries par nom.\n";
}

// Fonction pour sauvegarder les contacts dans un fichier
void sauvegarderContacts(const vector<Contact> &contacts) {
    ofstream fichier("contacts.txt", std::ios::app); // Ajouter un contact dans le fichier 

    if (fichier.is_open()) {
        for (const auto &contact : contacts) {
            fichier << contact.nom << ";" << contact.numero << ";" << contact.email << ";"
                    << contact.adresse << ";" << contact.sexe << endl;
        }
        fichier.close();
        cout << "Contacts sauvegardes avec succes.\n";
    } else {
        cout << "Erreur lors de l'ouverture du fichier pour sauvegarde.\n";
    }
}

// Fonction pour charger les contacts depuis un fichier
void chargerContacts(vector<Contact> &contacts) {
    // Ouvre le fichier "contacts.txt" en mode lecture
    ifstream fichier("contacts.txt");

    // Vérifie si le fichier a été ouvert correctement
    if (fichier.is_open()) {
        // Efface tous les contacts existants dans la liste pour éviter les doublons
        contacts.clear();
        
        string ligne;
        // Parcourt chaque ligne du fichier jusqu'à la fin
        while (getline(fichier, ligne)) {
            // Crée un nouvel objet Contact pour stocker les données de la ligne actuelle
            Contact contact;
            
            size_t pos = 0;  // Position de délimitation dans la ligne
            int index = 0;   // Indice pour déterminer quel champ de contact est lu
            
            // Boucle pour séparer les informations de la ligne en utilisant le point-virgule comme séparateur
            while ((pos = ligne.find(';')) != string::npos) {
                // Extrait la sous-chaîne jusqu'au prochain point-virgule
                string token = ligne.substr(0, pos);

                // Affecte chaque morceau d'information au champ approprié de l'objet Contact
                switch (index) {
                    case 0: contact.nom = token; break;       // Le premier élément est le nom
                    case 1: contact.numero = token; break;    // Le deuxième élément est le numéro de téléphone
                    case 2: contact.email = token; break;     // Le troisième élément est l'email
                    case 3: contact.adresse = token; break;   // Le quatrième élément est l'adresse
                    case 4: contact.sexe = token; break;      // Le cinquième élément est le sexe
                }
                
                // Supprime la partie traitée de la ligne pour continuer avec le reste
                ligne.erase(0, pos + 1);
                index++;  // Passe au champ suivant pour le contact
            }
            
            // Ajoute l'objet Contact rempli à la liste des contacts
            contacts.push_back(contact);
        }
        
        // Ferme le fichier après avoir terminé de lire toutes les lignes
        fichier.close();
        
        // Indique que les contacts ont été chargés avec succès
        cout << "Contacts charges avec succes.\n";
    } else {
        // Affiche un message d'erreur si le fichier ne peut pas être ouvert
        cout << "Erreur lors de l'ouverture du fichier pour chargement.\n";
    }
}


// Fonction principale
int main() {
    vector<Contact> listeContacts;  // Liste dynamique de contacts
    int choix;

    do {

        cout << "                  **TELEPHONE\n\n";
        cout << " ________________________________________________________________________\n";
        cout << "|                 Gestionnaire des contacts                              |\n";
        cout << "|________________________________________________________________________|\n";
        cout << "|Veuillez choisir l'une des options suivantes                            |\n";
        cout << "|          1. Ajouter un contact                                         |\n";
        cout << "|          2. Afficher tous les contacts du repertoire                   |\n";
        cout << "|          3. Rechercher un contact par son nom                          |\n";
        cout << "|          4. Supprimer un contact                                       |\n";
        cout << "|          5. Mettre a jour un contact                                   |\n";
        cout << "|          6. Trier les contacts par nom                                 |\n";
        cout << "|          7. Sauvegarder les contacts dans un fichier                   |\n";
        cout << "|          8. Charger les contacts depuis un fichier                     |\n";
        cout << "|          9. Quitter                                                    |\n";
        cout << "|________________________________________________________________________|\n";
       
        //ici on va permettre a l'utilisateur de faire son choix parmi les option disponible  
        cout << "\nChoix : ";
        cin >> choix;

        switch (choix) {
            case 1:
                ajouterContact(listeContacts);
                break;
            case 2:
                afficherListeContacts(listeContacts);
                break;
            case 3:
                rechercherContactParNom(listeContacts);
                break;
            case 4:
                supprimerContactParNom(listeContacts);
                break;
            case 5:
                modifierContact(listeContacts);
                break;
            case 6:
                trierContactsParNom(listeContacts);
                break;
            case 7:
                sauvegarderContacts(listeContacts);
                break;
            case 8:
                chargerContacts(listeContacts);
                break;
            case 9:
                cout << "Vous avez choisi de quitter le programme.\n";
                break;
            default:
                cout << "Choix invalide. Veuillez reessayer.\n";
        }
    } while (choix != 9);

    return 0;
}